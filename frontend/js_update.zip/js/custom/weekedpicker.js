var options = {
    twentyFour: true,  //Display 24 hour format, defaults to false
};
$('.timepicker').wickedpicker(options);
