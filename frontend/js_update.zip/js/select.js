$(function(){
    $('.selectpicker').selectpicker();
});