<?php 
return [
	'add_country' => 'Add Country',
	'country_name' => 'Country Name',
	'select_country' => 'Select Country',
	'city_name' => 'City name',
	'add_city' => 'Add City',
	'currency' => 'Currencies',
	'add_currency' => 'Add Currency',
	'currency_name' => 'Currency name',
	'two_letter_iso_code' => 'Two Letter ISO Code',
	'three_letter_iso_code' => 'Three Letter ISO Code',
	'country_code' => 'Country Code',
	'country_flag' => 'Country Flag',
];