<?php 

	return [
		'restaurant' => 'Restaurant',
		'food_category' => 'Food Category',
		'discount_price' => 'Discount Price',
		'ingredients' => 'Ingredients',
		'package_count' => 'Package Count',
		'featured_food' => 'Featured Food',
		'deliverable_food' => 'Deliverable Food',
		'add_food' => 'Add Food',
	];