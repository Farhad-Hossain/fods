<?php 

return [
	'extra_food_list' => 'Extra Foods List',
	'modal_title' => 'Add Extra Food',
	'add' => 'Add Extra Food',
	'edit_modal_title' => 'Edit Extra Food',
	'edit_btn' => 'Save Changes',
];