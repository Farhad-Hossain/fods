<?php 
	
return [
	'name' => 'Name',
	'email' => 'Email',
	'phone_number' => 'Phone Number',
	'password' => 'Password',
	'category' => 'Category',
	'status' => 'Status',
	'action' => 'Action',
	'description' => 'Description',
	'price' => 'Price',
	'new_record' => 'New Record',
	'image' => 'Image',
	'unit' => 'Unit',
	'weight' => 'Weight',
	'height' => 'Height',
	'yes' => 'Yes',
	'no' => 'No',
    'add' => 'Add',
    'close' => 'Close',
    'save_changes' => 'Save Changes',
    'time' => 'Time',
];