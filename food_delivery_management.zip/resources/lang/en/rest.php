<?php 

return [
	'name' => 'Restaurant name',
	'city' => 'City',
	'phone' => 'Restaurant Phone number',
	'website' => 'Restaurant Website',
	'status_open' => 'Open',
	'status_close' => 'Closed',
	'status' => 'Open Satatus',
	'alcohol_status' => 'Alcohol',
	'delivery_charge' => 'Delivery Charge',
	'selling_percentage' => 'Selling percentage',
	'payment_method' => 'Payment Method',
	'email' => 'Email',
	'website' => 'Website',
	'address' => 'Address',
	'restaurant_name' => 'Restaurant Name',
	'stars' => 'Stars',
	'reviews' => 'Reviews',
	'see_reviews' => 'See Reviews',
];