<?php 
	return [
		'cuisines' => 'Cuisines',
		'name' => 'Name',
		'status' => 'Status',
		'action' => 'Action',
		'modal_create_title' => 'Create Cuisine',
		'modal_edit_title' => 'Edit Modal',
	];
?>