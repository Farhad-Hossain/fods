<?php
return [
    'name' => 'Name',
    'image' => 'Image',
    'description' => 'Description',
    'action' => 'Action',
    'modal_edit_title' => 'Edit Category',
    'modal_add_title' => 'Add Category',
];
