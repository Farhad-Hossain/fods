<?php
return [
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'action' => 'Action',
    'modal_edit_title' => 'Edit User',
    'modal_add_title' => 'Add User'
];
