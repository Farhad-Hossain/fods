<?php 

	return [
		'transaction_type' => 'Transaction Type',
		'select_driver' => 'Select Driver',
		'select_customer' => 'Select Customer',
		'transaction_amount' => 'Transaction Amount',
		'create_customer_transaction' => 'Create Customer Transaction',
		'sele3ct_driver' => 'Select Driver',
		'transaction_form' => 'Transaction Form',
	];