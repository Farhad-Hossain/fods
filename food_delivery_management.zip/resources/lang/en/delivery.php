<?php 

return [
	'driver_registration' => 'Driver Registration',
	'max_delivery_distance' => 'Max Delivery Distance',
	'driver_edit' => 'Driver Edit',
];

