<?php 

return [
	'edit_food' => 'Edit Food',
	'restaurant' => 'Restaurant',
	'food_category' => 'Food category',
	'add_food' => 'Add Food',
	'food_name' => 'Food names',
	'star_count' => 'Rating Stars',
	'see_reviews' => 'Review',
	'reviewer' => 'Reviewer Name',
];