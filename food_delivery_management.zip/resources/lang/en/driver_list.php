<?php 
	return [
		'name' => 'Name',
		'contact' => 'Contact',
		'email' => 'Email',
		'action' => 'Action',
		'mmax_delivery_distance' => 'Delivery Distance',
		'current_status' => 'Current Availabity',
		'bike_status' => 'Bike Status',
	];
