<?php 

return [
	'tags' => 'Tags',
	'action' => 'Action',
	'name' => 'Name',
	'status' => 'Status',
	'modal_create_title' => 'Create Tag',
	'modal_edit_title' => 'Edit tag',
	
];