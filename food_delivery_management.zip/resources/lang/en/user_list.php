<?php 

	return [
		'user_list' => 'User list',
		'role' => 'Role',
	];