<?php 

return [
	'name' => 'Name',
	'owner' => 'Owner',
	'city' =>'City',
	'phone' => 'Phone',
	'address' => 'Address',
	'delivery_charge' => 'Delivery Charge',
	'systmem_commision' => 'System Commision',
	'payment_method' => 'Payment Method',
	'characteristics' => 'Characteristics',
	'open_status' => 'Open Status',
	'action' => 'Action',
];

?>